//
//  HelloWorldAppDelegate.h
//  HelloWorld
//
//  Created by Jesus Galvan on 9/3/14.
//  Copyright (c) 2014 CS378HW1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
