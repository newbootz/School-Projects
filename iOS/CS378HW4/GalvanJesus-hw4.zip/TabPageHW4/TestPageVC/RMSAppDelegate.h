//
//  RMSAppDelegate.h
//  TestPageVC
//
//  Created by Robert Seitsinger on 9/18/14.
//  Copyright (c) 2014 Infinity Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RMSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
