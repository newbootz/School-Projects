//
//  HW3AppDelegate.h
//  HW3
//
//  Created by JesGalvan on 9/16/14.
//  Copyright (c) 2014 CS378HW3. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HW3AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
