//
//  main.m
//  HelloWorld
//
//  Created by Jesus Galvan on 9/3/14.
//  Copyright (c) 2014 CS378HW1. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HelloWorldAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HelloWorldAppDelegate class]));
    }
}
